const db = require("../config/env");
const { dashboardSchema } = require("../config/dashboard.schema");
const { getBillingAnalytics } = require("./billing-analytics.module");
const { addAprilFilter } = require("../config/reporting-period");
const { APRIL_2026_START, getAprilToNowRange } = require("../config/reporting-period");

const number = (value) => Number(value || 0);
const money = (value) => Number(number(value).toFixed(2));

const getAnalytics = async (agentId, billingFilters = {}, options = {}) => {
  const [rows] = await db.query(
    "SELECT id, corporate_name AS clientName, is_active AS isActive FROM admins WHERE agent_id = ?",
    [agentId],
  );
  const clientNames = Object.fromEntries(rows.map((row) => [row.id, row.clientName || `Client ${row.id}`]));
  const serviceRows = await Promise.all(Object.entries(dashboardSchema).map(async ([service, schema]) => {
    // Analytics is invoice-driven. Bookings are joined only to resolve client and
    // booking metadata; a booking without an invoice must not be counted.
    if (!schema.invoiceTable) return [];

    const params = [agentId];
    const where = ["a.agent_id = ?", `b.${schema.isAssign} = 1`, `(b.${schema.childKey} IS NULL OR b.${schema.childKey} = 0)`];
    addAprilFilter(where, params, schema.bookedAt);
    const [invoices] = await db.query(
      `SELECT '${service}' AS service, b.${schema.id} AS bookingId,
        b.${schema.bookedAt} AS bookingDate, b.${schema.status} AS bookingStatus,
        b.admin_id AS clientId, a.corporate_name AS clientName,
        ${schema.isAssign ? `b.${schema.isAssign}` : "NULL"} AS isAssigned,
        ${schema.isCancelled ? `b.${schema.isCancelled}` : "NULL"} AS isCancelled,
        CASE WHEN ${schema.isCancelled ? `b.${schema.isCancelled} = 0 AND ` : ""}COALESCE(i.invoiceSubTotal, 0) > 0
          THEN i.invoiceSubTotal - COALESCE(i.taxiFees, 0) ELSE 0 END AS spend
       FROM (
         SELECT booking_id,
           SUM(${schema.invoiceAmount}) AS invoiceSubTotal,
           SUM(COALESCE(${schema.invoiceFees}, 0)${schema.invoiceExtraFees ? ` + COALESCE(${schema.invoiceExtraFees}, 0)` : ""}) AS taxiFees
         FROM ${schema.invoiceTable}
         WHERE is_cancelled = 0 OR is_cancelled IS NULL
         GROUP BY booking_id
       ) i
       INNER JOIN ${schema.table} b ON b.${schema.id} = i.booking_id
       INNER JOIN admins a ON a.id = b.admin_id
       WHERE ${where.join(" AND ")}`,
      params,
    );
    return invoices;
  }));

  const serviceWise = Object.fromEntries(
    Object.keys(dashboardSchema).map((service) => [service, { bookingCount: 0, spend: 0 }]),
  );
  const clientWise = {};
  const monthlyTrend = {};
  const dashboardWise = {};
  const monthStart = new Date(`${APRIL_2026_START}T00:00:00`);
  const nextMonthStart = getAprilToNowRange().end;
  // const bookingStatusDistribution = {};
  for (const booking of serviceRows.flat()) {
    const amount = number(booking.spend);
    const service = booking.service;
    const clientName = booking.clientName || clientNames[booking.clientId] || `Client ${booking.clientId}`;
    const status = booking.bookingStatus == null || booking.bookingStatus === "" ? "unknown" : String(booking.bookingStatus);
    const date = booking.bookingDate ? new Date(booking.bookingDate) : null;
    const month = date && !Number.isNaN(date.getTime()) ? date.toISOString().slice(0, 7) : "unknown";

    if (!serviceWise[service]) serviceWise[service] = { bookingCount: 0, spend: 0 };
    serviceWise[service].bookingCount += 1;
    serviceWise[service].spend += amount;

    if (!clientWise[clientName]) clientWise[clientName] = { bookingCount: 0, spend: 0 };
    clientWise[clientName].bookingCount += 1;
    clientWise[clientName].spend += amount;

    if (!monthlyTrend[month]) monthlyTrend[month] = { bookingCount: 0, spend: 0 };
    monthlyTrend[month].bookingCount += 1;
    monthlyTrend[month].spend += amount;

    if (!dashboardWise[service]) {
      dashboardWise[service] = {
        totalBookings: 0,
        totalSpend: 0,
        confirmedBookings: 0,
        cancelledBookings: 0,
        currentMonthBookings: 0,
        currentMonthSpend: 0,
      };
    }
    const summary = dashboardWise[service];
    summary.totalBookings += 1;
    summary.totalSpend += amount;
    if (Number(booking.isAssigned) === 1) summary.confirmedBookings += 1;
    if (Number(booking.isCancelled) === 1) summary.cancelledBookings += 1;
    if (date && date >= monthStart && date < nextMonthStart) {
      summary.currentMonthBookings += 1;
      summary.currentMonthSpend += amount;
    }
  }

  //   if (!bookingStatusDistribution[status]) bookingStatusDistribution[status] = { bookingCount: 0, spend: 0 };
  //   bookingStatusDistribution[status].bookingCount += 1;
  //   bookingStatusDistribution[status].spend += amount;
  // }

  const formatMetrics = (metrics) => Object.fromEntries(
    Object.entries(metrics).map(([key, value]) => [key, { bookingCount: value.bookingCount, spend: money(value.spend) }]),
  );
  const formattedClients = formatMetrics(clientWise);
  const billing = await getBillingAnalytics({ agentId, ...billingFilters });
  const topClientsBySpend = rows
    .map((client) => {
      const clientName = client.clientName || `Client ${client.id}`;
      const billingClient = billing.clientWise?.[clientName];
      return {
        clientName,
        bookingCount: formattedClients[clientName]?.bookingCount || 0,
        spend: money((billingClient?.totalUnbilled || 0) + (billingClient?.totalBilled || 0)),
      };
    })
    .sort((a, b) => b.spend - a.spend);
  const result = {
    serviceWise: formatMetrics(serviceWise),
    clientWise: formattedClients,
    monthlyTrend: formatMetrics(monthlyTrend),
    topClientsBySpend,
    billing,
  };
  if (options.includeDashboardData) {
    result.dashboardWise = dashboardWise;
    result.clientDirectory = rows;
  }
  return result;
};

module.exports = { getAnalytics };
